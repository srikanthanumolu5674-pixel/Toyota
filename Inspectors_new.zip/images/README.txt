INSPECTORS — Crown Block CAT-III NDT Report (HTML)
==================================================

All images are already extracted from the original PDF and saved in this
folder. Just open  ../index.html  in any browser — everything shows, no
placeholders. To get a PDF back out: open index.html in Chrome -> Ctrl+P ->
"Save as PDF", margins "Default", enable "Background graphics".

IMAGE FILE MAP
--------------
Branding (every page)
  watermark-iu.png   Faint centered "IU" watermark behind page content
  logo-iu.png        Inspectors Union Co. logo (top-left, transparent)
  logo-leea.png      LEEA "Full Member" logo (top-right)
  footer-asnt.png    ASNT logo (bottom strip)
  footer-tuv.png     TUV Rheinland "Certified" logo
  footer-drops.png   DROPS logo
  footer-iadc.png    IADC logo

Page 1
  crown-block-diagram.png   "CROWN BLOCK CAT III MPI FLAW POSITIONS" illustration
  site-photo.jpg            Crown block on-site photo
  qr-code.png               QR code (signature block)
  sign-inspector.png        Inspector signature (Duggineni Venu Kumar)
  sign-approver.png         Approver signature (Mohammad Ramzan Khan)
  stamp-qaqc.png            Round QA/QC "Inspectors Union Co." stamp

Page 2 — AFTER MPI (3x3)        mpi-1.jpg ... mpi-9.jpg
Page 3 — AFTER BUFFING (3x3)    buffing-1.jpg ... buffing-9.jpg
         small nameplate         nameplate-1.jpg
Page 4 — full nameplate          nameplate-large.jpg

Note: file names are referenced exactly by index.html — if you replace any
image keep the same filename.
